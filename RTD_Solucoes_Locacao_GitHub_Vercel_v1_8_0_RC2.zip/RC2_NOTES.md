# RTD Soluções — v1.8.0 RC2

Correções no fluxo de criação de acesso:
- o frontend agora preserva e interpreta corretamente o corpo de erro retornado pelo Supabase Auth;
- bloqueio de 60 segundos após tentativa de criação de acesso, evitando duplo clique e repetições que acionam rate limits;
- mensagem específica quando o limite de envio de e-mails é atingido;
- orientação visual para o cliente não repetir o cadastro.

Diagnóstico:
- a lógica da RC1 não fazia múltiplos requests por clique;
- o projeto está usando o provedor de e-mail padrão do Supabase, que possui limite muito baixo para e-mails de Auth;
- para lançamento público, configurar SMTP próprio é requisito operacional. O frontend sozinho não consegue remover esse limite.
